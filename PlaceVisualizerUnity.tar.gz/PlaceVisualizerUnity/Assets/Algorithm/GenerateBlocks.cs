﻿using Assets;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;
using Assets.Algorithm;

public class GenerateBlocks : MonoBehaviour
{
    public Material matToUse;
    public Material[] colourValues;
    public GameObject prefab;
    GameObject parent;
    public int[] colourCodes = new int[]{   0XFFFFFF, 0XE4E4E4, 0X888888, 0X222222,
                                                    0XFFA7D1, 0XE50000, 0XE59500, 0XA06A42,
                                                    0XE5D900, 0X94E044, 0X02BE01, 0X00E5F0,
                                                    0X0083C7, 0X0000EA, 0XE04AFF, 0X820080 };
    /// <summary>
    /// Call to generate our blocks in the scene
    /// </summary>
    public void generate()
    {
        colourValues = new Material[16];
        for (int i = 0; i < 16; i++)
        {
            int colourVal = colourCodes[i];
            int r = colourVal >> 16;
            int g = (colourVal >> 8) & 0xFF;
            int b = colourVal & 0xFF;

            if (!StaticVars.Transparent)
                colourValues[i] = new Material(matToUse);
            else
                colourValues[i] = new Material(Shader.Find("Transparent/Diffuse"));
            colourValues[i].color = new Color(r / 255f, g / 255f, b / 255f, 1);

        }

        if (parent != null)
        {
            GameObject.Destroy(parent);
        }

        parent = new GameObject("BLOCKS");
        generateColouredBlocks();
        DifferentGenTypes.NaiveGen(parent, prefab, colourValues, StaticVars.Transparent);
        for(int i = 0; i < 16; i++)
        {
            StaticVars.ColouredBlocks[i].transform.parent = parent.transform;
        }
        parent.transform.Rotate(Vector3.right, 180f);
    }


    private void generateColouredBlocks()
    {
        StaticVars.ColouredBlocks = new GameObject[16];
        StaticVars.ColouredBlocks[0] = new GameObject("White");
        StaticVars.ColouredBlocks[1] = new GameObject("Light Gray");
        StaticVars.ColouredBlocks[2] = new GameObject("Medium Gray");
        StaticVars.ColouredBlocks[3] = new GameObject("Dark Gray");
        StaticVars.ColouredBlocks[4] = new GameObject("Light Pink");
        StaticVars.ColouredBlocks[5] = new GameObject("Red");
        StaticVars.ColouredBlocks[6] = new GameObject("Orange");
        StaticVars.ColouredBlocks[7] = new GameObject("Brown");
        StaticVars.ColouredBlocks[8] = new GameObject("Yellow");
        StaticVars.ColouredBlocks[9] = new GameObject("Lime");
        StaticVars.ColouredBlocks[10] = new GameObject("Green");
        StaticVars.ColouredBlocks[11] = new GameObject("Light Blue");
        StaticVars.ColouredBlocks[12] = new GameObject("Medium Blue");
        StaticVars.ColouredBlocks[13] = new GameObject("Dark Blue");
        StaticVars.ColouredBlocks[14] = new GameObject("Pink");
        StaticVars.ColouredBlocks[15] = new GameObject("Violet");
        foreach (GameObject g in StaticVars.ColouredBlocks)
        {
            g.transform.parent = parent.transform;
        }
    }


}

