﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets.Algorithm
{
    public class MeshCombiner
    {
        int parentColourObj;
        int numberOfVerts = 0;
        public MeshCombiner(int i)
        {
            parentColourObj = i;
            allCubes = new List<List<CombineInstance>>();
        }


        public List<List<CombineInstance>> allCubes;

        public void Add(CombineInstance instance)
        {
            if(allCubes.Count < 1 || numberOfVerts > 60000)
            {
                allCubes.Add(new List<CombineInstance>());
                numberOfVerts = 0;
            }
            allCubes.Last().Add(instance);
            numberOfVerts += instance.mesh.vertexCount;
        }
    }
}

