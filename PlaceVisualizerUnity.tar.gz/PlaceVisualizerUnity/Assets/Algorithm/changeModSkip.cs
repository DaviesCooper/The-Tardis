﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class changeModSkip : MonoBehaviour {

    public InputField input;

	public void changeMod()
    {
        int mod = 0;
        if (Int32.TryParse(input.text, out mod))
        {
            FileReader.modSkip = Int32.Parse(input.text);
            SceneLoading.LoadScene(1);
        }
    }
}
