﻿using Assets;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ObjectRefs : MonoBehaviour
{
    public InputField xMin;
    public InputField xMax;
    public InputField yMin;
    public InputField yMax;
    public InputField zMin;
    public InputField zMax;
    public InputField xScale;
    public InputField yScale;
    public InputField zScale;
    public Slider slider;
    public GameObject plane1;
    public GameObject plane2;
    public GameObject plane3;

    public void ClampInputFields()
    {
        try
        {
            StaticVars.xMin = Mathf.Clamp(Int32.Parse(xMin.text), 0, FileReader.binary.GetLength(0) - 1);
            xMin.text = "" + StaticVars.xMin;
            StaticVars.xMax = Mathf.Clamp(Int32.Parse(xMax.text), StaticVars.xMin + 1, FileReader.binary.GetLength(0));
            xMax.text = "" + StaticVars.xMax;
            StaticVars.yMin = Mathf.Clamp(Int32.Parse(yMin.text), 0, FileReader.binary.GetLength(1) - 1);
            yMin.text = "" + StaticVars.yMin;
            StaticVars.yMax = Mathf.Clamp(Int32.Parse(yMax.text), StaticVars.yMin + 1, FileReader.binary.GetLength(1));
            yMax.text = "" + StaticVars.yMax;
            StaticVars.zMin = Mathf.Clamp(Int32.Parse(zMin.text), 0, FileReader.binary.GetLength(2) - 1);
            zMin.text = "" + StaticVars.zMin;
            StaticVars.zMax = Mathf.Clamp(Int32.Parse(zMax.text), StaticVars.zMin + 1, FileReader.binary.GetLength(2));
            zMax.text = "" + StaticVars.zMax;
            StaticVars.xScale = Mathf.Clamp(float.Parse(xScale.text), 0, 50);
            xScale.text = "" + StaticVars.xScale;
            StaticVars.yScale = Mathf.Clamp(float.Parse(yScale.text), 0, 50);
            yScale.text = "" + StaticVars.yScale;
            StaticVars.zScale = Mathf.Clamp(float.Parse(zScale.text), 0, 50);
            zScale.text = "" + StaticVars.zScale;
            StaticVars.initXMin = Mathf.Clamp(Int32.Parse(xMin.text), 0, FileReader.binary.GetLength(0) - 1);
            StaticVars.initXMax = Mathf.Clamp(Int32.Parse(xMax.text), StaticVars.xMin + 1, FileReader.binary.GetLength(0));
            StaticVars.initYMin = Mathf.Clamp(Int32.Parse(yMin.text), 0, FileReader.binary.GetLength(1) - 1);
            StaticVars.initYMax = Mathf.Clamp(Int32.Parse(yMax.text), StaticVars.yMin + 1, FileReader.binary.GetLength(1));
            StaticVars.initZMin = Mathf.Clamp(Int32.Parse(zMin.text), 0, FileReader.binary.GetLength(2) - 1);
            StaticVars.initZMax = Mathf.Clamp(Int32.Parse(zMax.text), StaticVars.zMin + 1, FileReader.binary.GetLength(2));
        }
        catch (Exception)
        {
            Debug.Log("unity is a piece of shit");
        }
    }


}
