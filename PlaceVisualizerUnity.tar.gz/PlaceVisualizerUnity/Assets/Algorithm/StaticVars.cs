﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets
{
    public static class StaticVars
    {
        public static int xMin;
        public static int xMax;
        public static int yMin;
        public static int yMax;
        public static int zMin;
        public static int zMax;


        public static int initXMin;
        public static int initXMax;
        public static int initYMin;
        public static int initYMax;
        public static int initZMin;
        public static int initZMax;

        public static bool Transparent = false;

        public static float xScale;
        public static float yScale;
        public static float zScale;

        public static int maxCubes = 2000000;

        //All values set
        public static bool[] toggles = new bool[]{  true, true, true, true,
                                                    true, true, true, true,
                                                    true, true, true, true,
                                                    true, true, true, true};


        public static GameObject[] ColouredBlocks = new GameObject[16];
    }
}
