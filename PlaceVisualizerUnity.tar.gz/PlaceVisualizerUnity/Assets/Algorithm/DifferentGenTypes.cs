﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets.Algorithm
{
    public static class DifferentGenTypes
    {
        public static void NaiveGen(GameObject Parent, GameObject prefab, Material[] colourValues, bool combineMeshes)
        {
            ObjectRefs refs = GameObject.FindObjectOfType<ObjectRefs>();
            int[,,] Tardis = FileReader.binary;
            int xMax = StaticVars.xMax;
            int xMin = StaticVars.xMin;
            int yMax = StaticVars.yMax;
            int yMin = StaticVars.yMin;
            int zMax = StaticVars.zMax;
            int zMin = StaticVars.zMin;
            float xScale = StaticVars.xScale;
            float yScale = StaticVars.yScale;
            float zScale = StaticVars.zScale;

            //Set parent Transform
            Parent.transform.position = new Vector3((xMax - xMin) / 2, (yMax - yMin) / 2, (zMax - zMin) / 2);

            MeshCombiner[] tempObjs = new MeshCombiner[16];
            for (int i = 0; i < 16; i++)
            {
                tempObjs[i] = new MeshCombiner(i);
            }

            //Generate the blocks, and parent them to their proper parent
            for (int k = zMin; k < zMax; k++)
            {
                for (int i = xMin; i < xMax; i++)
                {
                    for (int j = yMin; j < yMax; j++)
                    {
                        int c = Tardis[i, j, k];
                        if (c != -1 && StaticVars.toggles[c])
                        {

                            GameObject reference = GameObject.Instantiate(prefab);
                            reference.name = "(" + i + "," + j + "," + FileReader.modSkip * k + ")";
                            reference.transform.localScale = new Vector3(StaticVars.xScale, StaticVars.yScale, StaticVars.zScale);
                            reference.transform.position += new Vector3((i * StaticVars.xScale) - (xMin * StaticVars.xScale),
                                                                        (j * StaticVars.yScale) - (yMin * StaticVars.yScale),
                                                                        (k * StaticVars.zScale) - (zMin * StaticVars.zScale));
                            CombineInstance ci = new CombineInstance();
                            ci.mesh = reference.GetComponent<MeshFilter>().sharedMesh;
                            ci.transform = reference.GetComponent<MeshFilter>().transform.localToWorldMatrix;
                            tempObjs[c].Add(ci);
                            reference.SetActive(false);

                        }
                    }
                }
            }


            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < tempObjs[i].allCubes.Count; j++)
                {
                    GameObject newGO = new GameObject();
                    newGO.AddComponent<MeshFilter>().mesh = new Mesh();
                    int verts = 0;
                    tempObjs[i].allCubes[j].ForEach(k => verts += k.mesh.vertexCount);
                    newGO.GetComponent<MeshFilter>().mesh.CombineMeshes(tempObjs[i].allCubes[j].ToArray());
                    newGO.AddComponent<MeshRenderer>().material = colourValues[i];
                    newGO.AddComponent<ClippableObject>();
                    
                    newGO.transform.parent = StaticVars.ColouredBlocks[i].transform;
                }

            }
        }

        public static void ComplexGen()
        {
            int[,,] Tardis = FileReader.binary;
        }
    }
}
