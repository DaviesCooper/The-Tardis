﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Behaviours
{
    class SliderBehaviours : MonoBehaviour
    {
        private GenerateBlocks blocks; 

        public void Start()
        {
            blocks = GameObject.FindObjectOfType<GenerateBlocks>();
        }

        public void ZPressed(int amount)
        {
            StaticVars.zMin+=amount;
            StaticVars.zMax+=amount;
            StaticVars.zMin = Mathf.Clamp(StaticVars.zMin, 0, FileReader.binary.GetLength(2) - 1);
            StaticVars.zMax = Mathf.Clamp(StaticVars.zMax, StaticVars.zMin + 1, FileReader.binary.GetLength(2));
            blocks.generate();
        }
        public void XPressed(int amount)
        {
            StaticVars.xMin += amount;
            StaticVars.xMax += amount;
            StaticVars.xMin = Mathf.Clamp(StaticVars.xMin, 0, FileReader.binary.GetLength(0) - 1);
            StaticVars.xMax = Mathf.Clamp(StaticVars.xMax, StaticVars.xMin + 1, FileReader.binary.GetLength(0));
            blocks.generate();
        }
        public void YPressed(int amount)
        {
            StaticVars.yMin += amount;
            StaticVars.yMax += amount;
            StaticVars.yMin = Mathf.Clamp(StaticVars.yMin, 0, FileReader.binary.GetLength(1) - 1);
            StaticVars.yMax = Mathf.Clamp(StaticVars.yMax, StaticVars.yMin + 1, FileReader.binary.GetLength(1));
            blocks.generate();
        }

    }
}
