﻿using Assets;
using System;
using UnityEngine;
using UnityEngine.UI;

public class ToggleBoxes : MonoBehaviour
{
    /// <summary>
    /// Turns a colour on or off
    /// </summary>
    /// <param name="valueToToggle"></param>
    public void toggleMask(int valueToToggle)
    {
        StaticVars.toggles[valueToToggle] = !StaticVars.toggles[valueToToggle];
        try
        {
            StaticVars.ColouredBlocks[valueToToggle].SetActive(StaticVars.toggles[valueToToggle]);
        }
        catch (NullReferenceException)
        {
            Debug.Log("No object exists yet");
        }
    }
}
