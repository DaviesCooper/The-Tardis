﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reset : MonoBehaviour {

    public GameObject plane1;
    public GameObject plane2;
    public GameObject plane3;

    public void ResetCamera()
    {
        Camera.main.transform.position = new Vector3(-1,0,15);
        Camera.main.transform.rotation = Quaternion.identity;
    }

    public void ResetPlanes()
    {
        Vector3 position = new Vector3(-1, 0, 15);
        plane1.transform.position = position;
        plane1.transform.localRotation = Quaternion.Euler(0, 0, 0);

        plane2.transform.position = position;
        plane2.transform.localRotation = Quaternion.Euler(0, 0, -90);

        plane3.transform.position = position;
        plane3.transform.localRotation = Quaternion.Euler(-90, 0, 0);

    }


}
