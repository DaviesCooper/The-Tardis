﻿using Assets;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TransparencyBehaviour : MonoBehaviour
{

    public Slider slider;
    GenerateBlocks blocks;

    // Use this for initialization
    void Start()
    {
        blocks = FindObjectOfType<GenerateBlocks>();
    }

    // Update is called once per frame
    void Update()
    {

    }


    public void ChangeOpacity()
    {
        for (int i = 0; i < 16; i++)
        {
            if (StaticVars.toggles[i])
            {
                try
                {
                    Color newColour = StaticVars.ColouredBlocks[i].GetComponent<MeshRenderer>().material.color;
                    newColour.a = slider.value;
                    StaticVars.ColouredBlocks[i].GetComponent<MeshRenderer>().material.color = newColour;
                }
                catch (Exception) { }
                
            }
            Color newA = blocks.colourValues[i].color;
            newA.a = slider.value;
            blocks.colourValues[i].color = newA;
        }
    }
}
