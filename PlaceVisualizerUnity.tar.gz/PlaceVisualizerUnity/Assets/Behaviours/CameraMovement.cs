﻿using UnityEngine;

public class CameraMovement : MonoBehaviour
{

    public float lookSpeedH = 20f;
    public float lookSpeedV = 20f;
    public float zoomSpeed = 20f;
    public float dragSpeed = 60f;

    private float yaw = 0f;
    private float pitch = 0f;

    void Update()
    {
        
        //Look around with Right Mouse
        if (Input.GetMouseButton(1))
        {
            Cursor.lockState = CursorLockMode.Confined; // keep confined in the game window
            Cursor.lockState = CursorLockMode.Locked;   // keep confined to center of screen
            
            yaw += lookSpeedH * Input.GetAxis("Mouse X");
            pitch -= lookSpeedV * Input.GetAxis("Mouse Y");

            transform.eulerAngles = new Vector3(pitch, yaw, 0f);
        }

        //drag camera around with Middle Mouse
        else if (Input.GetMouseButton(2))
        {
            Cursor.lockState = CursorLockMode.Confined; // keep confined in the game window
            Cursor.lockState = CursorLockMode.Locked;   // keep confined to center of screen
            transform.Translate(-Input.GetAxisRaw("Mouse X") * Time.deltaTime * dragSpeed, -Input.GetAxisRaw("Mouse Y") * Time.deltaTime * dragSpeed, 0);
        }

        else
        {
            Cursor.lockState = CursorLockMode.None;     // set to default default
        }

        //Zoom in and out with Mouse Wheel
        transform.Translate(0, 0, Input.GetAxis("Mouse ScrollWheel") * zoomSpeed, Space.Self);
    }
}