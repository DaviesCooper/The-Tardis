﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoading : MonoBehaviour {

    public static void LoadScene(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex, LoadSceneMode.Single);
    }

}
