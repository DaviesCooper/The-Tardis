using UnityEngine;
using System.Collections;
using System.Linq;

public class ClippableObject : MonoBehaviour
{

    Vector3 plane1Position;
    Vector3 plane1Rotation;

    Vector3 plane2Position;
    Vector3 plane2Rotation;

    Vector3 plane3Position;
    Vector3 plane3Rotation;
    ObjectRefs refs;

    public void Start()
    {
        refs = FindObjectOfType<ObjectRefs>();
    }

    //Ideally the planes do not need to be updated every frame, but we'll just keep the logic here for simplicity purposes.
    public void Update()
    {
        plane1Position = refs.plane1.transform.position;
        plane1Rotation = refs.plane1.transform.eulerAngles;

        plane2Position = refs.plane2.transform.position;
        plane2Rotation = refs.plane2.transform.eulerAngles;

        plane3Position = refs.plane3.transform.position;
        plane3Rotation = refs.plane3.transform.eulerAngles;

        var sharedMaterial = GetComponent<MeshRenderer>().sharedMaterial;


        sharedMaterial.DisableKeyword("CLIP_ONE");
        sharedMaterial.DisableKeyword("CLIP_TWO");
        sharedMaterial.EnableKeyword("CLIP_THREE");



        sharedMaterial.SetVector("_planePos", plane1Position);
        //plane normal vector is the rotated 'up' vector.
        sharedMaterial.SetVector("_planeNorm", Quaternion.Euler(plane1Rotation) * Vector3.up);

        sharedMaterial.SetVector("_planePos2", plane2Position);
        sharedMaterial.SetVector("_planeNorm2", Quaternion.Euler(plane2Rotation) * Vector3.up);

        sharedMaterial.SetVector("_planePos3", plane3Position);
        sharedMaterial.SetVector("_planeNorm3", Quaternion.Euler(plane3Rotation) * Vector3.up);

    }
}
