﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneOutline : MonoBehaviour
{
    LineRenderer outLine;
    public Material mat;
    public float outlinewidth;

    // Use this for initialization
    void Start()
    {
        outLine = gameObject.AddComponent<LineRenderer>();
        initLine(outLine);
    }

    public void initLine(LineRenderer line)
    {
        line.material = mat;
        line.widthMultiplier = outlinewidth;
    }

    // Update is called once per frame
    void Update()
    {
        DrawPlane();
    }


    private void DrawPlane()
    {
        Vector3[] verts = GetComponent<MeshFilter>().mesh.vertices;
        

        outLine.SetPositions(verts);
    }
}
