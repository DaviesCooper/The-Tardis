﻿using Assets;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ToggleSophisticated : MonoBehaviour {

    public GameObject transparencySlider;
	public void sophisticatedToggle()
    {
        StaticVars.Transparent = !StaticVars.Transparent;
        transparencySlider.SetActive(!transparencySlider.activeSelf);
    }
}
