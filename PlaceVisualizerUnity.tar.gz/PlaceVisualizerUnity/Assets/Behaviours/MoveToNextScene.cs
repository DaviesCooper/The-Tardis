﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveToNextScene : MonoBehaviour
{

    public void goNext()
    {
        SceneLoading.LoadScene(1);
    }
}
