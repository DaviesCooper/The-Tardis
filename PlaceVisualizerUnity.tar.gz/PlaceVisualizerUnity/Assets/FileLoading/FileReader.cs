﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using tileRead.Datastructures.InputEncoding;
using UnityEngine;

public static class FileReader
{

    public static int modSkip = 1800000;

    public static int[,,] binary;

    public static void fromBinary(string filePath)
    {

        FileStream fs = new FileStream(filePath, FileMode.Open);
        try
        {
            BinaryFormatter formatter = new BinaryFormatter();

            // Deserialize the hashtable from the file and 
            // assign the reference to the local variable.
            binary = (int[,,])formatter.Deserialize(fs);
        }
        catch (SerializationException e)
        {
            Debug.Log("Failed to deserialize. Reason: " + e.Message);
            throw;
        }
        finally
        {
            fs.Close();
        }
    }


    //{
    //    Entry[] entries = Entry.readEntriesFromFile(filePath);
    //    List<Entry> entryls = entries.ToList();
    //    entryls.Sort(delegate (Entry one, Entry two) { return one.time.CompareTo(two.time); });
    //    entries = entryls.ToArray();
    //    long last = entries[entries.Length - 1].time;
    //    long first = entries[0].time;
    //    int sections = (int)((last - first) / modSkip);
    //    int[,,] Tardis = new int[1001, 1001, sections + 1];
    //    for (int i = 0; i < 1001; i++)
    //    {
    //        for (int j = 0; j < 1001; j++)
    //        {
    //            for (int k = 0; k < sections + 1; k++)
    //            {
    //                Tardis[i, j, k] = -1;
    //            }
    //        }
    //    }

    //    long startTime = entries[0].time;
    //    for (int i = 0; i < entries.Length; i++)
    //    {
    //        int x = entries[i].x;
    //        int y = entries[i].y;
    //        int z = (int)((entries[i].time - startTime) / modSkip);
    //        Tardis[x, y, z] = entries[i].colourID;
    //    }

    //    for (int i = 0; i < 1001; i++)
    //    {
    //        for (int j = 0; j < 1001; j++)
    //        {
    //            for (int k = 1; k < sections + 1; k++)
    //            {
    //                if (Tardis[i, j, k] == -1)
    //                    Tardis[i, j, k] = Tardis[i, j, k - 1];
    //            }
    //        }
    //    }
    //    Debug.Log("DONE FILE READING");
    //    binary = Tardis;
}