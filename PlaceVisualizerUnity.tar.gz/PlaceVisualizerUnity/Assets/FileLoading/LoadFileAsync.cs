﻿using System.Threading;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadFileAsync : MonoBehaviour {

    

    // Use this for initialization
    void Start ()
    {
        string path = Application.streamingAssetsPath + "/array.bin";
        Thread newThread = new Thread(() => FileReader.fromBinary(path));
        newThread.Start();
	}

    private void Update()
    {
        if (FileReader.binary != null)
        {
            SceneLoading.LoadScene(2);
        }
    }

}
